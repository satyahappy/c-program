#include<stdio.h>
int main()
{
    printf("hello how r u");
    return 0;
}